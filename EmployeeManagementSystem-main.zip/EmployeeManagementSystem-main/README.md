# A React based Employee Management System
An employee task management web application that supports role-based login (admin and employee) and provides features like task creation, updating, marking as completed/failed, and viewing task statistics.

## Project Link : https://employee-management-system-lac-six.vercel.app/

## User Login Credentials
Below are the default login credentials to access the application:

Admin Login

Email: admin@example.com
Password: 123

Employee Logins

Employee 1:
Email: aarav@example.com
Password: 123

Employee 2:
Email: neha@example.com
Password: 123

Employee 3:
Email: rohan@example.com
Password: 123

Employee 4:
Email: priya@example.com
Password: 123

Employee 5:
Email: vikram@example.com
Password: 123


